import os
import sys
import tkinter as tk
from tkinter import filedialog
import qrcode
from PIL import Image, ImageOps, ImageFilter
from rich.console import Console

console = Console()


# ================== GRADIENT BANNER ==================

def print_banner():
    banner_lines = [
        " ██████╗ ██████╗      ██████╗  ███████╗███╗   ██╗",
        "██╔═══██╗██╔══██╗     ██╔════╝ ██╔════╝████╗  ██║",
        "██║   ██║██████╔╝     ██║  ███╗█████╗  ██╔██╗ ██║",
        "██║▄▄ ██║██╔══██╗     ██║   ██║██╔══╝  ██║╚██╗██║",
        "╚██████╔╝██║  ██║     ╚██████╔╝███████╗██║ ╚████║",
        " ╚══▀▀═╝ ╚═╝  ╚═╝      ╚═════╝ ╚══════╝╚═╝  ╚═══╝",
    ]

    total = len(banner_lines)

    for i, line in enumerate(banner_lines):
        ratio = i / total

        # Cyan (0,255,255) → Blue (0,0,255)
        r = 0
        g = int(255 * (1 - ratio))
        b = 255

        console.print(line, style=f"rgb({r},{g},{b}) bold")

    console.print("        QR GEN - BY SPIRE\n", style="bold cyan")


# ================== DOSYA SEÇ ==================

def dosya_sec(baslik, tip):
    root = tk.Tk()
    root.withdraw()
    root.attributes("-topmost", True)

    if tip == "ac":
        yol = filedialog.askopenfilename(
            title=baslik,
            filetypes=[("Resim Dosyaları", "*.png *.jpg *.jpeg *.bmp")]
        )
    else:
        yol = filedialog.asksaveasfilename(
            title=baslik,
            defaultextension=".png",
            filetypes=[("PNG Dosyası", "*.png")]
        )

    root.destroy()
    return yol


# ================== ULTRA STABLE ENGINE ==================

def create_safe_qr(url, bg_path, save_path):
    try:
        console.print("[yellow]Arka plan hazırlanıyor...[/yellow]")

        bg = Image.open(bg_path).convert("RGBA")
        min_dim = min(bg.size)
        size = (min_dim, min_dim)
        bg = ImageOps.fit(bg, size, Image.LANCZOS)

        # Arka planı yumuşat (QR daha net görünür)
        bg = bg.filter(ImageFilter.GaussianBlur(2))

        console.print("[yellow]QR oluşturuluyor...[/yellow]")

        qr = qrcode.QRCode(
            version=None,
            error_correction=qrcode.constants.ERROR_CORRECT_H,
            box_size=20,
            border=4
        )

        qr.add_data(url)
        qr.make(fit=True)

        qr_img = qr.make_image(fill_color="black", back_color="white").convert("RGBA")
        qr_img = qr_img.resize(size, Image.NEAREST)

        # Beyazları şeffaf yap, siyahlar saf siyah kalsın
        pixels = qr_img.load()

        for y in range(size[1]):
            for x in range(size[0]):
                r, g, b, a = pixels[x, y]
                if r > 200:  # beyaz alan
                    pixels[x, y] = (0, 0, 0, 0)
                else:
                    pixels[x, y] = (0, 0, 0, 255)  # tam siyah

        final = Image.alpha_composite(bg, qr_img)

        console.print("[green]Kaydediliyor...[/green]")
        final.save(save_path, "PNG", quality=100)

        return True, size

    except Exception as e:
        console.print(f"[red]Hata: {e}[/red]")
        return False, None


# ================== MAIN ==================

def main():
    os.system('cls' if os.name == 'nt' else 'clear')
    print_banner()

    url = input("QR için link gir: ").strip()
    if not url:
        console.print("[red]Link girmedin.[/red]")
        return

    console.print("\nArka plan görselini seç:")
    bg_path = dosya_sec("Arka Plan Seç", "ac")
    if not bg_path:
        console.print("[red]İptal edildi.[/red]")
        return

    console.print("\nQR nereye kaydedilsin?")
    save_path = dosya_sec("Kaydet", "kaydet")
    if not save_path:
        console.print("[red]İptal edildi.[/red]")
        return

    basari, size = create_safe_qr(url, bg_path, save_path)

    if basari:
        console.print("\n" + "="*45)
        console.print(" QR HAZIR - SCANNER SAFE ", style="bold green")
        console.print(f"Boyut: {size[0]}x{size[1]}")
        console.print(f"Kayıt: {save_path}")
        console.print("="*45)


if __name__ == "__main__":
    main()
